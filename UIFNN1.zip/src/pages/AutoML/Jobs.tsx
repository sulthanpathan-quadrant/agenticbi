// import { useState, useMemo, useEffect } from "react";
// import { useNavigate } from "react-router-dom";
// import { motion } from "framer-motion";
// import {
//   Play,
//   Eye,
//   Edit,
//   Plus,
//   Grid3X3,
//   BarChart2,
//   RefreshCw,
//   Loader2,
//   Database,
// } from "lucide-react";
// import { Button } from "@/components/ui/button";
// import {
//   Dialog,
//   DialogContent,
//   DialogHeader,
//   DialogTitle,
//   DialogFooter,
// } from "@/components/ui/dialog";
// import { Input } from "@/components/ui/input";
// import { Label } from "@/components/ui/label";
// import Header from "@/components/layout/Header";
// import Chatbot from "@/components/chatbot/Chatbot";
// import { useJobs } from "@/components/contexts/JobsContext";
// import { useAuth } from "@/components/contexts/AuthContext";
// import { Job } from "@/components/types/jobs";
// import JobViewModal from "@/components/modals/JobViewModal";
// import JobEditModal from "@/components/modals/JobEditModal";
// import { prepareDataset } from "@/components/utils/preparedDataset";
// import { toast } from "sonner";
// import { cn } from "@/lib/utils";
 
// // ─── Add these new interfaces ───
// interface GlobalDataset {
//   id: string;
//   jobName: string;
//   datasetName: string;
//   lastRun: string;
//   completedAt: string;
//   rows: number;
//   columns: number;
//   filePath: string;
//   isScheduled: boolean;
//   job_id?: string;
// }
 
// interface JobSpecificDataset {
//   filename: string;
//   date_modified: string;
// }
 
// interface PreviewData {
//   columns: string[];
//   preview_rows: Record<string, any>[];
//   total_rows: number;
//   preview_row_count: number;
//   // add more fields if your API returns them
// }
 
// // Map UI feature names to API task names
// const featureToTaskMap: Record<string, string> = {
//   Classification: "classification",
//   Regression: "regression",
//   Forecasting: "forecasting",
//   Clustering: "clustering",
//   "Anomaly Detection": "anomaly_detection",
// };
 
// // Map UI model names to API model names
// const modelNameToAPI: Record<string, string> = {
//   "Logistic Regression": "logistic_regression",
//   "Random Forest": "random_forest",
//   "Gradient Boosting": "gradient_boosting",
//   XGBoost: "xgboost",
//   Ridge: "ridge",
//   ARIMA: "arima",
//   Prophet: "prophet",
//   LightGBM: "lightgbm",
//   CatBoost: "catboost",
//   KMeans: "kmeans",
//   "KMeans++": "kmeans++",
//   DBSCAN: "dbscan",
//   GMM: "gmm",
//   "Isolation Forest": "isolation_forest",
//   "One-Class SVM": "one_class_svm",
//   "Local Outlier Factor (LOF)": "lof",
//   "Elliptic Envelope": "elliptic_envelope",
// };
 
// // Reverse mapping: API names to UI names
// const apiModelToUI: Record<string, string> = {
//   logistic_regression: "Logistic Regression",
//   random_forest: "Random Forest",
//   gradient_boosting: "Gradient Boosting",
//   xgboost: "XGBoost",
//   ridge: "Ridge",
//   arima: "ARIMA",
//   prophet: "Prophet",
//   lightgbm: "LightGBM",
//   catboost: "CatBoost",
//   kmeans: "KMeans",
//   "kmeans++": "KMeans++",
//   dbscan: "DBSCAN",
//   gmm: "GMM",
//   isolation_forest: "Isolation Forest",
//   one_class_svm: "One-Class SVM",
//   lof: "Local Outlier Factor (LOF)",
//   elliptic_envelope: "Elliptic Envelope",
// };
 
// const AutoMLJobs = () => {
//   const navigate = useNavigate();
//   const { isAuthenticated, user } = useAuth();
//   const {
//     jobs,
//     loading,
//     error,
//     totalCount,
//     currentPage,
//     fetchJobs,
//     updateJob,
//     setCurrentPage,
//   } = useJobs();
 
//   const [statusFilter, setStatusFilter] = useState("all");
//   const [selectedJob, setSelectedJob] = useState<Job | null>(null);
//   const [isViewModalOpen, setIsViewModalOpen] = useState(false);
//   const [isEditModalOpen, setIsEditModalOpen] = useState(false);
//   const [runningJobId, setRunningJobId] = useState<string | null>(null);
//   const [runningMessage, setRunningMessage] = useState<string>("");
//   const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
//   const [jobName, setJobName] = useState("");
//   // Add these new states after the existing ones (e.g. after setIsCreateModalOpen etc.)
//   const [globalDatasets, setGlobalDatasets] = useState<GlobalDataset[]>([]);
//   const [jobDatasets, setJobDatasets] = useState<JobSpecificDataset[]>([]);
//   const [selectedDataset, setSelectedDataset] = useState<
//     GlobalDataset | JobSpecificDataset | null
//   >(null);
//   const [previewData, setPreviewData] = useState<PreviewData | null>(null);
//   const [dsLoading, setDsLoading] = useState(true);
//   const [activeDsTab, setActiveDsTab] = useState<"global" | "job">("global");
//   const [previewLoading, setPreviewLoading] = useState(false);
 
//   const itemsPerPage = 10;
//   const totalPages = Math.ceil(totalCount / itemsPerPage);
 
//   // Replace or add this useEffect (make sure it's separate from the dataset loading one)
//   // (status filtering is done client-side on the loaded jobs — no need to send status to backend yet)
//   useEffect(() => {
//     fetchJobs(currentPage);
//   }, [currentPage]); // ← add fetchJobs to deps if it's from context
 
//   useEffect(() => {
//     if (statusFilter !== "all") {
//       setCurrentPage(1);
//     }
//   }, [statusFilter]);
 
//   // Add this complete useEffect block
//   useEffect(() => {
//     const loadDatasets = async () => {
//       setDsLoading(true);
 
//       const userRaw = localStorage.getItem("user");
//       if (!userRaw) {
//         toast.error("User information not found");
//         setDsLoading(false);
//         return;
//       }
 
//       const userData = JSON.parse(userRaw);
//       const userId = userData.user_id || userData.id;
 
//       if (!userId) {
//         toast.error("User ID not found");
//         setDsLoading(false);
//         return;
//       }
 
//       // A. Global datasets
//       try {
//         const res = await fetch(
//           `https://api.veriton.ai/api/service2/datasets?user_id=${userId}`,
//         );
//         if (res.ok) {
//           const data = await res.json();
//           const mapped = data.map((item: any, idx: number) => ({
//             id: String(idx + 1),
//             jobName: item.job_name || "Unnamed Job",
//             datasetName: item.dataset_name || "Unnamed Dataset",
//             lastRun: item.completed_at
//               ? new Date(item.completed_at).toLocaleString()
//               : "—",
//             completedAt: item.completed_at,
//             rows: item.rows || 0,
//             columns: item.columns_count || 0,
//             filePath: item.file_path || "",
//             isScheduled: item.is_scheduled || false,
//             job_id: item.job_id,
//           }));
//           setGlobalDatasets(mapped);
//         }
//       } catch (err) {
//         console.error("Global datasets fetch failed", err);
//       }
 
//       // B. Job-specific datasets
//       const currentJobId = localStorage.getItem("current_job_id");
//       if (currentJobId) {
//         try {
//           const res = await fetch(
//             `https://api.veriton.ai/api/service2/list-datasets?user_id=${userId}&job_id=${currentJobId}`,
//           );
//           if (res.ok) {
//             const data = await res.json();
//             setJobDatasets(data.datasets || []);
//           }
//         } catch (err) {
//           console.error("Job-specific datasets fetch failed", err);
//         }
//       }
 
//       setDsLoading(false);
 
//       // Auto-select if coming from DatasetTab
//       const preName = localStorage.getItem("selected_dataset_name");
//       if (preName) {
//         const found =
//           jobDatasets.find((d) => d.filename === preName) ||
//           globalDatasets.find((d) => d.datasetName === preName);
//         if (found) handleSelectDataset(found);
//       }
//     };
 
//     loadDatasets();
//   }, []);
 
//   const filteredJobs = useMemo(() => {
//     if (statusFilter === "all") return jobs;
 
//     return jobs.filter(
//       (job) => job.status.toLowerCase() === statusFilter.toLowerCase(),
//     );
//   }, [jobs, statusFilter]);
 
//   const paginatedJobs = useMemo(() => {
//     const start = (currentPage - 1) * itemsPerPage;
 
//     const end = start + itemsPerPage;
 
//     return filteredJobs.slice(start, end);
//   }, [filteredJobs, currentPage]);
 
//   const formatDate = (date: Date | null) => {
//     if (!date) return "—";
//     return new Intl.DateTimeFormat("en-US", {
//       year: "numeric",
//       month: "2-digit",
//       day: "2-digit",
//     })
//       .format(date)
//       .replace(/\//g, "-");
//   };
 
//   const getStatusBadge = (status: Job["status"]) => {
//     const styles = {
//       completed: "bg-emerald-100 text-emerald-700",
//       pending: "bg-amber-100 text-amber-700",
//       running: "bg-amber-100 text-amber-700",
//       failed: "bg-red-100 text-red-700",
//     };
 
//     const labels = {
//       completed: "Completed",
//       pending: "Running",
//       running: "Running",
//       failed: "Failed",
//     };
 
//     return (
//       <span
//         className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${styles[status]}`}
//       >
//         {labels[status]}
//       </span>
//     );
//   };
 
//   const handleRun = async (job: Job) => {
//     // Check if job has basic configuration
//     console.log("Job config:", {
//       category: job.category,
//       features: job.features,
//       target: job.target,
//       datasetName: job.datasetName,
//     });
 
//     if (!job.category && !job.feature) {
//       alert("Job is missing task type (category). Please edit the job first.");
//       return;
//     }
 
//     if (!job.target) {
//       alert("Job is missing target column. Please edit the job first.");
//       return;
//     }
 
//     if (!job.datasetName) {
//       alert("Job is missing dataset. Please edit the job first.");
//       return;
//     }
 
//     setRunningJobId(job.id);
//     setRunningMessage("Preparing dataset...");
 
//     try {
//       const userDataString = localStorage.getItem("aivolve_user");
//       if (!userDataString) {
//         throw new Error("User not found");
//       }
 
//       const userData = JSON.parse(userDataString);
//       const userEmail = userData.email;
//       const agentName = userData.agent_name || userData.name || "default";
//       const userId = userData.user_id || userData.id || "";
 
//       // ✅ If features are not loaded, fetch them now
//       let features = job.features || [];
 
//       if (features.length === 0) {
//         setRunningMessage("Loading dataset features...");
 
//         const blobPath = `${userId}/${agentName}/${job.datasetName}`;
//         const previewUrl = `https://api.veriton.ai/api/service3/data_preview?blob_path=${encodeURIComponent(blobPath)}&user_email=${encodeURIComponent(userEmail)}`;
 
//         const previewResponse = await fetch(previewUrl, {
//           method: "GET",
//           headers: { accept: "application/json" },
//         });
 
//         if (!previewResponse.ok) {
//           throw new Error(
//             `Failed to fetch dataset features: ${previewResponse.status}`,
//           );
//         }
 
//         const previewData = await previewResponse.json();
 
//         if (!previewData.preview?.columns) {
//           throw new Error("Invalid dataset preview");
//         }
 
//         // Get all columns except target
//         features = previewData.preview.columns.filter(
//           (col: string) => col !== job.target,
//         );
 
//         if (features.length === 0) {
//           throw new Error("No features available for training.");
//         }
 
//         console.log("Fetched features:", features);
//       }
 
//       // Step 1: Download file from blob storage
//       setRunningMessage("Downloading dataset...");
//       const blobPath = `${userId}/${agentName}/${job.datasetName}`;
//       const downloadUrl = `https://api.veriton.ai/api/service3/download_predictions?blob_path=${encodeURIComponent(blobPath)}&user_email=${encodeURIComponent(userEmail)}`;
 
//       const downloadResponse = await fetch(downloadUrl, {
//         method: "GET",
//         headers: { accept: "application/json" },
//       });
 
//       if (!downloadResponse.ok) {
//         throw new Error(`Failed to download file: ${downloadResponse.status}`);
//       }
 
//       const csvText = await downloadResponse.text();
//       const fileBlob = new Blob([csvText], { type: "text/csv" });
 
//       // Step 2: Prepare FormData for training
//       setRunningMessage("Training model... This may take a few minutes.");
//       const formData = new FormData();
//       formData.append("file", fileBlob, job.datasetName);
//       formData.append(
//         "task",
//         featureToTaskMap[job.category] || job.category.toLowerCase(),
//       );
//       formData.append("target", job.target);
//       formData.append("user_email", userEmail);
 
//       const apiModelName = job.model
//         ? modelNameToAPI[job.model] ||
//           job.model.toLowerCase().replace(/\s+/g, "_")
//         : "";
//       formData.append("models", apiModelName);
//       formData.append("metric", "");
//       formData.append("preprocessing_mode", "simple");
//       formData.append("use_cleaning", "true");
//       formData.append("use_feature_selection", "true");
//       formData.append("use_optuna", "true");
//       formData.append("optuna_trials", "2");
//       formData.append("time_budget", "180");
//       formData.append("test_size", "0.2");
//       formData.append("test_file", "");
 
//       // Step 3: Call build_ml_model API
//       const buildResponse = await fetch(
//         "https://api.veriton.ai/api/service3/build_ml_model",
//         {
//           method: "POST",
//           body: formData,
//         },
//       );
 
//       if (!buildResponse.ok) {
//         const errorData = await buildResponse.json().catch(() => ({}));
//         throw new Error(
//           errorData.detail || `API failed: ${buildResponse.status}`,
//         );
//       }
 
//       const result = await buildResponse.json();
//       console.log("Model trained successfully:", result);
 
//       // Convert API model name back to UI format
//       const uiModelName =
//         apiModelToUI[result.best_model?.toLowerCase()] || result.best_model;
 
//       // Update job with new results
//       updateJob(job.id, {
//         id: result.model_id,
//         feature: job.category,
//         model: uiModelName,
//         features: features, // ✅ Save the features we used
//         category: job.category,
//         target: job.target,
//         status: "completed",
//         task_type: result.task_type,
//         testAccuracy: result.primary_score?.toString(),
//         lastRun: new Date(),
//       });
 
//       setRunningMessage("Training complete! Opening results...");
 
//       // Wait a bit for the update to propagate
//       await new Promise((resolve) => setTimeout(resolve, 500));
 
//       // Step 4: Open JobViewModal with updated job
//       const updatedJob = {
//         ...job,
//         id: result.model_id,
//         features: features,
//         status: "completed" as const,
//         lastRun: new Date(),
//       };
 
//       setSelectedJob(updatedJob);
//       setIsViewModalOpen(true);
//     } catch (err) {
//       const errorMessage =
//         err instanceof Error ? err.message : "Failed to train model";
//       alert(`Error: ${errorMessage}`);
//       console.error("Error training model:", err);
//     } finally {
//       setRunningJobId(null);
//       setRunningMessage("");
//     }
//   };
 
//   // Add these two functions (e.g. after handleRun or before return)
//   const handleSelectDataset = async (
//     ds: GlobalDataset | JobSpecificDataset,
//   ) => {
//     setSelectedDataset(ds);
//     setPreviewData(null);
//     setPreviewLoading(true);
 
//     const userRaw = localStorage.getItem("user");
//     const user = userRaw ? JSON.parse(userRaw) : null;
//     const userId = user?.user_id || user?.id;
 
//     if (!userId) {
//       toast.error("User ID not found");
//       setPreviewLoading(false);
//       return;
//     }
 
//     // ─── This is the important change ───
//     let jobId: string | undefined;
//     let datasetName: string;
 
//     if ("job_id" in ds && ds.job_id) {
//       // Global dataset from /datasets API → use its own job_id
//       jobId = ds.job_id;
//       datasetName = ds.datasetName;
//     } else if ("filename" in ds) {
//       // Job-specific dataset from /list-datasets → fallback to current_job_id
//       jobId = localStorage.getItem("current_job_id") || undefined;
//       datasetName = ds.filename;
//     }
 
//     if (!jobId) {
//       toast.error("Cannot preview: no job ID associated with this dataset");
//       setPreviewLoading(false);
//       return;
//     }
 
//     try {
//       const url = `https://api.veriton.ai/api/service2/preview-dataset?user_id=${userId}&job_id=${jobId}&datasetname=${encodeURIComponent(datasetName)}`;
 
//       const res = await fetch(url);
//       if (!res.ok) {
//         const errText = await res.text().catch(() => "");
//         throw new Error(`Preview failed (${res.status}): ${errText}`);
//       }
 
//       const data = await res.json();
//       setPreviewData(data);
//     } catch (err: any) {
//       console.error("Preview error:", err);
//       toast.error(err.message || "Failed to load dataset preview");
//     } finally {
//       setPreviewLoading(false);
//     }
//   };
 
//   const startWorkflow = async (mode: "build" | "compare") => {
//     if (!selectedDataset) return;
 
//     const userRaw = localStorage.getItem("user");
//     const user = userRaw ? JSON.parse(userRaw) : null;
//     const userId = user?.user_id || user?.id;
 
//     let jobId: string | undefined;
//     let filename: string;
 
//     if ("job_id" in selectedDataset && selectedDataset.job_id) {
//       jobId = selectedDataset.job_id;
//       filename = selectedDataset.datasetName;
//     } else if ("filename" in selectedDataset) {
//       jobId = localStorage.getItem("current_job_id") || undefined;
//       filename = selectedDataset.filename;
//     }
 
//     if (!userId || !jobId || !filename) {
//       toast.error("Cannot start: missing job ID or filename");
//       return;
//     }
 
//     try {
//       const prepared = await prepareDataset(userId, jobId, filename);
//       if (prepared) {
//         navigate(
//           mode === "compare"
//             ? "/workflow/automl/compare"
//             : "/workflow/automl/build-model",
//           {
//             state: {
//               dataset: prepared,
//               mode: mode === "compare" ? "compare" : undefined,
//             },
//           },
//         );
//       }
//     } catch (err: any) {
//       toast.error(`Preparation failed for "${filename}": ${err.message}`);
//     }
//   };
 
//   const handleView = (job: Job) => {
//     setSelectedJob(job);
//     setIsViewModalOpen(true);
//   };
 
//   const handleEdit = (job: Job) => {
//     setSelectedJob(job);
//     setIsEditModalOpen(true);
//   };
 
//   const handleCreateJob = () => {
//     if (jobName.trim()) {
//       navigate("/workflow/automl/select-dataset", {
//         state: { jobName: jobName.trim(), initialTab: "data-source" },
//       });
//       setIsCreateModalOpen(false);
//       setJobName("");
//     }
//   };
 
//   const handleRefresh = async () => {
//     await fetchJobs(currentPage);
//   };
 
//   //   if (!isAuthenticated) return null;
 
//   return (
//     <div className="min-h-screen h-screen bg-background flex flex-col overflow-hidden">
//       <Header />
 
//       <div className="flex-1 flex flex-col overflow-auto">
//         <main className="px-6 py-6">
//           <div className="max-w-7xl mx-auto w-full">
//             {/* ================= AutoML Intro ================= */}
 
//             <div className="mb-10 flex items-start justify-between">
//               <div>
//                 <h1 className="text-3xl font-bold text-foreground">
//                   AutoML Workspace
//                 </h1>
 
//                 <p className="text-muted-foreground mt-2 max-w-2xl">
//                   Build, compare, and test machine learning models automatically
//                   using your datasets. Manage all trained models below.
//                 </p>
//               </div>
 
//               <div className="flex items-center gap-3">
//                 <Button
//                   variant="outline"
//                   onClick={() =>
//                     navigate("/workflow/automl/test", {
//                       state: { initialTab: "test" },
//                     })
//                   } // ← your test flow path
//                 >
//                   Test Model
//                 </Button>
//               </div>
//             </div>
//             {/* ─── NEW: Dataset Selection Section ─── */}
//             {/* ================= DATASET SECTION ================= */}
 
//             <div className="bg-card border border-border rounded-xl shadow-sm mb-10 overflow-hidden">
//               {/* Header */}
//               <div className="px-6 py-4 border-b">
//                 <h2 className="text-lg font-semibold">Select Dataset</h2>
//               </div>
 
//               <div className="flex h-[480px]">
//                 {/* ================= Sidebar – all datasets in one list ================= */}
//                 <div className="w-[300px] border-r bg-muted/20 overflow-y-auto">
//                   {dsLoading ? (
//                     <div className="p-6 text-sm text-muted-foreground">
//                       Loading datasets...
//                     </div>
//                   ) : globalDatasets.length === 0 &&
//                     jobDatasets.length === 0 ? (
//                     <div className="p-6 text-sm text-muted-foreground">
//                       No datasets available
//                     </div>
//                   ) : (
//                     // ─── Flat combined list: global + job-specific ───
//                     [...globalDatasets, ...jobDatasets].map((ds) => {
//                       const isGlobal = "datasetName" in ds;
//                       const name = isGlobal ? ds.datasetName : ds.filename;
 
//                       const rows = isGlobal ? ds.rows : null;
//                       const columns = isGlobal ? ds.columns : null;
//                       const dateInfo = isGlobal ? ds.lastRun : ds.date_modified;
 
//                       const isSelected =
//                         selectedDataset &&
//                         ((isGlobal &&
//                           "datasetName" in selectedDataset &&
//                           selectedDataset.datasetName === name) ||
//                           (!isGlobal &&
//                             "filename" in selectedDataset &&
//                             selectedDataset.filename === name));
 
//                       return (
//                         <button
//                           key={`${isGlobal ? "g" : "j"}-${name}`}
//                           onClick={() => handleSelectDataset(ds)}
//                           className={cn(
//                             "w-full text-left px-5 py-4 border-l-2 transition-all duration-200",
//                             isSelected
//                               ? "border-primary bg-background"
//                               : "border-transparent hover:bg-background",
//                           )}
//                         >
//                           <div className="font-medium text-sm truncate">
//                             {name}
//                           </div>
 
//                           <div className="text-xs text-muted-foreground mt-1 flex flex-wrap gap-x-2">
//                             {rows != null && (
//                               <>
//                                 {rows} rows<span className="mx-1">•</span>
//                               </>
//                             )}
//                             {columns != null && (
//                               <>
//                                 {columns} columns<span className="mx-1">•</span>
//                               </>
//                             )}
//                             {dateInfo && (
//                               <span>
//                                 {isGlobal ? "Last run: " : "Modified: "}
//                                 {dateInfo}
//                               </span>
//                             )}
//                           </div>
//                         </button>
//                       );
//                     })
//                   )}
//                 </div>
 
//                 {/* ================= Preview Panel ================= */}
 
//                 <div className="flex-1 flex flex-col bg-background">
//                   {selectedDataset ? (
//                     <>
//                       {/* Preview Header */}
 
//                       <div className="px-6 py-4 border-b flex items-center justify-between">
//                         <div>
//                           <h3 className="font-semibold">
//                             {"datasetName" in selectedDataset &&
//                               selectedDataset.datasetName}
//                           </h3>
 
//                           <p className="text-xs text-muted-foreground">
//                             Dataset Preview
//                           </p>
//                         </div>
 
//                         <div className="flex gap-2">
//                           <Button
//                             size="sm"
//                             onClick={() => startWorkflow("build")}
//                             disabled={!previewData}
//                           >
//                             Build Model
//                           </Button>
 
//                           <Button
//                             size="sm"
//                             variant="outline"
//                             onClick={() => startWorkflow("compare")}
//                             disabled={!previewData}
//                           >
//                             Compare
//                           </Button>
//                         </div>
//                       </div>
 
//                       {/* Preview Table */}
 
//                       <div className="flex-1 overflow-auto">
//                         {previewLoading ? (
//                           <div className="flex items-center justify-center h-full text-sm text-muted-foreground">
//                             Loading preview...
//                           </div>
//                         ) : previewData ? (
//                           <table className="w-full text-sm">
//                             <thead className="bg-muted sticky top-0">
//                               <tr>
//                                 {previewData.columns.map((col) => (
//                                   <th
//                                     key={col}
//                                     className="px-4 py-3 text-left border-b"
//                                   >
//                                     {col}
//                                   </th>
//                                 ))}
//                               </tr>
//                             </thead>
 
//                             <tbody>
//                               {previewData.preview_rows.map((row, i) => (
//                                 <tr key={i} className="hover:bg-muted/30">
//                                   {previewData.columns.map((col) => (
//                                     <td
//                                       key={col}
//                                       className="px-4 py-2 border-b"
//                                     >
//                                       {row[col] ?? "—"}
//                                     </td>
//                                   ))}
//                                 </tr>
//                               ))}
//                             </tbody>
//                           </table>
//                         ) : (
//                           <div className="flex items-center justify-center h-full text-muted-foreground">
//                             Preview not available
//                           </div>
//                         )}
//                       </div>
//                     </>
//                   ) : (
//                     <div className="flex items-center justify-center h-full text-muted-foreground">
//                       Select a dataset to preview
//                     </div>
//                   )}
//                 </div>
//               </div>
//             </div>
 
//             {/* Header */}
//             <div className="flex items-start justify-between mb-8">
//               <div>
//                 <h1 className="text-3xl font-bold text-foreground mb-1">
//                   Trained Models
//                 </h1>
//                 {/* <p className="text-muted-foreground">All machine learning models created using AutoML.</p> */}
//               </div>
//               <div className="flex items-center gap-3"></div>
//             </div>
 
//             {/* Error Display */}
//             {error && (
//               <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center justify-between">
//                 <p className="text-red-700 text-sm">{error}</p>
//                 <Button variant="outline" size="sm" onClick={handleRefresh}>
//                   Try Again
//                 </Button>
//               </div>
//             )}
 
//             {/* Running Job Status */}
//             {runningJobId && (
//               <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg flex items-center gap-3">
//                 <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
//                 <div>
//                   <p className="text-blue-800 font-medium text-sm">
//                     Training in progress...
//                   </p>
//                   <p className="text-blue-600 text-xs mt-0.5">
//                     {runningMessage}
//                   </p>
//                 </div>
//               </div>
//             )}
 
//             {/* Filters Row */}
//             <div className="flex items-center justify-between mb-6">
//               <div className="flex items-center gap-1 bg-muted/50 rounded-full p-1">
//                 {["all", "completed", "running", "failed"].map((status) => (
//                   <button
//                     key={status}
//                     onClick={() => setStatusFilter(status)}
//                     className={`px-4 py-2 text-sm font-medium rounded-full transition-colors ${
//                       statusFilter === status
//                         ? "bg-primary text-primary-foreground"
//                         : "text-muted-foreground hover:text-foreground"
//                     }`}
//                   >
//                     {status === "all"
//                       ? "All"
//                       : status.charAt(0).toUpperCase() + status.slice(1)}
//                   </button>
//                 ))}
//               </div>
//             </div>
 
//             {/* Jobs Table */}
//             <motion.div
//               initial={{ opacity: 0, y: 20 }}
//               animate={{ opacity: 1, y: 0 }}
//               className="bg-card rounded-xl border border-border overflow-hidden"
//             >
//               <div className="overflow-x-auto">
//                 <table className="w-full">
//                   <thead>
//                     <tr className="border-b border-border">
//                       <th className="px-6 py-4 text-left text-sm font-medium text-muted-foreground">
//                         Job
//                       </th>
//                       <th className="px-6 py-4 text-left text-sm font-medium text-muted-foreground">
//                         Category
//                       </th>
//                       <th className="px-6 py-4 text-left text-sm font-medium text-muted-foreground">
//                         Model
//                       </th>
//                       <th className="px-6 py-4 text-left text-sm font-medium text-muted-foreground">
//                         Created At
//                       </th>
//                       <th className="px-6 py-4 text-left text-sm font-medium text-muted-foreground">
//                         Last Run
//                       </th>
//                       <th className="px-6 py-4 text-left text-sm font-medium text-muted-foreground">
//                         Status
//                       </th>
//                       <th className="px-6 py-4 text-left text-sm font-medium text-primary">
//                         Actions
//                       </th>
//                     </tr>
//                   </thead>
//                   <tbody>
//                     {loading ? (
//                       <tr>
//                         <td colSpan={7} className="px-6 py-12 text-center">
//                           <div className="flex items-center justify-center gap-2">
//                             <RefreshCw className="w-5 h-5 animate-spin text-primary" />
//                             <span className="text-muted-foreground">
//                               Loading jobs...
//                             </span>
//                           </div>
//                         </td>
//                       </tr>
//                     ) : filteredJobs.length === 0 ? (
//                       <tr>
//                         <td colSpan={7} className="px-6 py-16 text-center">
//                           <h3 className="text-lg font-semibold mb-2">
//                             No models created yet
//                           </h3>
//                           <p className="text-sm text-muted-foreground mb-4">
//                             Start by building your first AutoML model.
//                           </p>
//                           <Button
//                             onClick={() =>
//                               navigate("/workflow/automl/select-dataset")
//                             }
//                           >
//                             Build Your First Model
//                           </Button>
//                         </td>
//                       </tr>
//                     ) : (
//                       filteredJobs.map((job, index) => {
//                         const jobNumber =
//                           (currentPage - 1) * itemsPerPage + index + 1;
//                         return (
//                           <motion.tr
//                             key={job.id}
//                             initial={{ opacity: 0 }}
//                             animate={{ opacity: 1 }}
//                             transition={{ delay: index * 0.03 }}
//                             className="border-b border-border/50 hover:bg-muted/20"
//                           >
//                             <td className="px-6 py-4 font-medium text-foreground">
//                               Job_{jobNumber}
//                             </td>
//                             <td className="px-6 py-4 text-primary">
//                               {job.category || "Unknown"}
//                             </td>
//                             <td className="px-6 py-4 text-muted-foreground">
//                               {job.model}
//                             </td>
//                             <td className="px-6 py-4 text-muted-foreground">
//                               {formatDate(job.createdAt)}
//                             </td>
//                             <td className="px-6 py-4 text-muted-foreground">
//                               {formatDate(job.lastRun)}
//                             </td>
//                             <td className="px-6 py-4">
//                               {getStatusBadge(job.status)}
//                             </td>
//                             <td className="px-6 py-4">
//                               <div className="flex items-center gap-3">
//                                 <button
//                                   onClick={() => handleRun(job)}
//                                   disabled={runningJobId === job.id}
//                                   className="text-muted-foreground hover:text-foreground transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
//                                   title="Run job"
//                                 >
//                                   {runningJobId === job.id ? (
//                                     <Loader2 className="w-5 h-5 animate-spin" />
//                                   ) : (
//                                     <Play className="w-5 h-5" />
//                                   )}
//                                 </button>
//                                 <button
//                                   onClick={() => handleView(job)}
//                                   className="text-muted-foreground hover:text-foreground transition-colors"
//                                   title="View details"
//                                 >
//                                   <Eye className="w-5 h-5" />
//                                 </button>
//                                 <button
//                                   onClick={() => handleEdit(job)}
//                                   className="text-muted-foreground hover:text-foreground transition-colors"
//                                   title="Edit job"
//                                 >
//                                   <Edit className="w-5 h-5" />
//                                 </button>
//                               </div>
//                             </td>
//                           </motion.tr>
//                         );
//                       })
//                     )}
//                   </tbody>
//                 </table>
//               </div>
//             </motion.div>
 
//             {/* Pagination */}
//             {totalPages > 1 && (
//               <div className="flex items-center justify-center gap-2 mt-6">
//                 <button
//                   onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
//                   disabled={currentPage === 1}
//                   className="p-2 rounded-lg text-muted-foreground hover:text-foreground disabled:opacity-50"
//                 >
//                   ‹
//                 </button>
//                 {Array.from({ length: Math.min(totalPages, 10) }, (_, i) => {
//                   const page = i + 1;
//                   if (
//                     totalPages <= 10 ||
//                     page <= 3 ||
//                     page > totalPages - 2 ||
//                     Math.abs(page - currentPage) <= 1
//                   ) {
//                     return (
//                       <button
//                         key={page}
//                         onClick={() => setCurrentPage(page)}
//                         className={`w-10 h-10 rounded-full text-sm font-medium transition-colors ${
//                           currentPage === page
//                             ? "bg-primary text-primary-foreground"
//                             : "text-muted-foreground hover:text-foreground"
//                         }`}
//                       >
//                         {page}
//                       </button>
//                     );
//                   } else if (page === 4 && currentPage > 5) {
//                     return (
//                       <span key="dots1" className="text-muted-foreground">
//                         ...
//                       </span>
//                     );
//                   } else if (
//                     page === totalPages - 2 &&
//                     currentPage < totalPages - 4
//                   ) {
//                     return (
//                       <span key="dots2" className="text-muted-foreground">
//                         ...
//                       </span>
//                     );
//                   }
//                   return null;
//                 })}
//                 <button
//                   onClick={() =>
//                     setCurrentPage((p) => Math.min(totalPages, p + 1))
//                   }
//                   disabled={currentPage === totalPages}
//                   className="p-2 rounded-lg text-muted-foreground hover:text-foreground disabled:opacity-50"
//                 >
//                   ›
//                 </button>
//               </div>
//             )}
//           </div>
//         </main>
 
//         {/* Create Job Modal */}
//         <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
//           <DialogContent className="sm:max-w-md">
//             <DialogHeader>
//               <DialogTitle>Create New Job</DialogTitle>
//             </DialogHeader>
//             <div className="space-y-4 py-4">
//               <div className="space-y-2">
//                 <Label htmlFor="job-name">Job Name</Label>
//                 <Input
//                   id="job-name"
//                   placeholder="Enter job name..."
//                   value={jobName}
//                   onChange={(e) => setJobName(e.target.value)}
//                   onKeyDown={(e) => {
//                     if (e.key === "Enter") handleCreateJob();
//                   }}
//                   autoFocus
//                 />
//               </div>
//             </div>
//             <DialogFooter>
//               <Button
//                 variant="outline"
//                 onClick={() => setIsCreateModalOpen(false)}
//               >
//                 Cancel
//               </Button>
//               <Button onClick={handleCreateJob} disabled={!jobName.trim()}>
//                 Next: Select Datasource
//               </Button>
//             </DialogFooter>
//           </DialogContent>
//         </Dialog>
 
//         {/* Modals */}
//         <JobViewModal
//           isOpen={isViewModalOpen}
//           onClose={() => setIsViewModalOpen(false)}
//           job={selectedJob}
//         />
 
//         <JobEditModal
//           isOpen={isEditModalOpen}
//           onClose={() => setIsEditModalOpen(false)}
//           job={selectedJob}
//         />
 
//         {/* Chatbot */}
//         <Chatbot />
//       </div>
//     </div>
//   );
// };
 
// export default AutoMLJobs;
 
 

import { useState, useMemo, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Play,
  Eye,
  Edit,
  Plus,
  Grid3X3,
  BarChart2,
  RefreshCw,
  Loader2,
  Database,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import Header from "@/components/layout/Header";
import Chatbot from "@/components/chatbot/Chatbot";
import { useJobs } from "@/components/contexts/JobsContext";
import { useAuth } from "@/components/contexts/AuthContext";
import { Job } from "@/components/types/jobs";
import JobViewModal from "@/components/modals/JobViewModal";
import JobEditModal from "@/components/modals/JobEditModal";
import { prepareDataset } from "@/components/utils/preparedDataset";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
 
// ─── Add these new interfaces ───
interface GlobalDataset {
  id: string;
  jobName: string;
  datasetName: string;
  lastRun: string;
  completedAt: string;
  rows: number;
  columns: number;
  filePath: string;
  isScheduled: boolean;
  job_id?: string;
}
 
interface JobSpecificDataset {
  filename: string;
  date_modified: string;
}
 
interface PreviewData {
  columns: string[];
  preview_rows: Record<string, any>[];
  total_rows: number;
  preview_row_count: number;
  // add more fields if your API returns them
}
 
// Map UI feature names to API task names
const featureToTaskMap: Record<string, string> = {
  Classification: "classification",
  Regression: "regression",
  Forecasting: "forecasting",
  Clustering: "clustering",
  "Anomaly Detection": "anomaly_detection",
};
 
// Map UI model names to API model names
const modelNameToAPI: Record<string, string> = {
  "Logistic Regression": "logistic_regression",
  "Random Forest": "random_forest",
  "Gradient Boosting": "gradient_boosting",
  XGBoost: "xgboost",
  Ridge: "ridge",
  ARIMA: "arima",
  Prophet: "prophet",
  LightGBM: "lightgbm",
  CatBoost: "catboost",
  KMeans: "kmeans",
  "KMeans++": "kmeans++",
  DBSCAN: "dbscan",
  GMM: "gmm",
  "Isolation Forest": "isolation_forest",
  "One-Class SVM": "one_class_svm",
  "Local Outlier Factor (LOF)": "lof",
  "Elliptic Envelope": "elliptic_envelope",
};
 
// Reverse mapping: API names to UI names
const apiModelToUI: Record<string, string> = {
  logistic_regression: "Logistic Regression",
  random_forest: "Random Forest",
  gradient_boosting: "Gradient Boosting",
  xgboost: "XGBoost",
  ridge: "Ridge",
  arima: "ARIMA",
  prophet: "Prophet",
  lightgbm: "LightGBM",
  catboost: "CatBoost",
  kmeans: "KMeans",
  "kmeans++": "KMeans++",
  dbscan: "DBSCAN",
  gmm: "GMM",
  isolation_forest: "Isolation Forest",
  one_class_svm: "One-Class SVM",
  lof: "Local Outlier Factor (LOF)",
  elliptic_envelope: "Elliptic Envelope",
};
 
const AutoMLJobs = () => {
  const navigate = useNavigate();
  const { isAuthenticated, user } = useAuth();
  const {
    jobs,
    loading,
    error,
    totalCount,
    currentPage,
    fetchJobs,
    updateJob,
    setCurrentPage,
  } = useJobs();
 
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [runningJobId, setRunningJobId] = useState<string | null>(null);
  const [runningMessage, setRunningMessage] = useState<string>("");
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [jobName, setJobName] = useState("");
  // Add these new states after the existing ones (e.g. after setIsCreateModalOpen etc.)
  const [globalDatasets, setGlobalDatasets] = useState<GlobalDataset[]>([]);
  const [jobDatasets, setJobDatasets] = useState<JobSpecificDataset[]>([]);
  const [selectedDataset, setSelectedDataset] = useState<
    GlobalDataset | JobSpecificDataset | null
  >(null);
  const [previewData, setPreviewData] = useState<PreviewData | null>(null);
  const [dsLoading, setDsLoading] = useState(true);
  const [activeDsTab, setActiveDsTab] = useState<"global" | "job">("global");
  const [previewLoading, setPreviewLoading] = useState(false);
  const [selectedFilePath, setSelectedFilePath] = useState<string>('')
 
  const itemsPerPage = 10;
  const totalPages = Math.ceil(totalCount / itemsPerPage);
 
  // Replace or add this useEffect (make sure it's separate from the dataset loading one)
  // (status filtering is done client-side on the loaded jobs — no need to send status to backend yet)
  useEffect(() => {
    fetchJobs(currentPage);
  }, [currentPage]); // ← add fetchJobs to deps if it's from context
 
  useEffect(() => {
    if (statusFilter !== "all") {
      setCurrentPage(1);
    }
  }, [statusFilter]);
 
  // Add this complete useEffect block
  useEffect(() => {
    const loadDatasets = async () => {
      setDsLoading(true);
 
      const userRaw = localStorage.getItem("user");
      if (!userRaw) {
        toast.error("User information not found");
        setDsLoading(false);
        return;
      }
 
      const userData = JSON.parse(userRaw);
      const userId = userData.user_id || userData.id;
 
      if (!userId) {
  toast.error("User ID not found")
  setDsLoading(false)
  return
}

let fetchedGlobal: GlobalDataset[] = []
let fetchedJob: JobSpecificDataset[] = []

// A. Global datasets
 
      // A. Global datasets
      try {
        const res = await fetch(
          `https://api.veriton.ai/api/service2/datasets?user_id=${userId}`,
        );
        if (res.ok) {
          const data = await res.json();
          const mapped = data.map((item: any, idx: number) => ({
            id: String(idx + 1),
            jobName: item.job_name || "Unnamed Job",
            datasetName: item.dataset_name || "Unnamed Dataset",
            lastRun: item.completed_at
              ? new Date(item.completed_at).toLocaleString()
              : "—",
            completedAt: item.completed_at,
            rows: item.rows || 0,
            columns: item.columns_count || 0,
            filePath: item.file_path || "",
            isScheduled: item.is_scheduled || false,
            job_id: item.job_id,
          }));
          fetchedGlobal = mapped
setGlobalDatasets(mapped)
        }
      } catch (err) {
        console.error("Global datasets fetch failed", err);
      }
 
      // B. Job-specific datasets
      const currentJobId = localStorage.getItem("current_job_id");
      if (currentJobId) {
        try {
          const res = await fetch(
            `https://api.veriton.ai/api/service2/list-datasets?user_id=${userId}&job_id=${currentJobId}`,
          );
          if (res.ok) {
            const data = await res.json();
           fetchedJob = data.datasets || []
setJobDatasets(fetchedJob)
          }
        } catch (err) {
          console.error("Job-specific datasets fetch failed", err);
        }
      }
 
setDsLoading(false)

// Auto-select first dataset directly from fetched local variables
const allFetched = [...fetchedJob, ...fetchedGlobal]
if (allFetched.length > 0) {
  handleSelectDataset(allFetched[0])
}
    };
 
    loadDatasets();
  }, []);
 
  const filteredJobs = useMemo(() => {
    if (statusFilter === "all") return jobs;
 
    return jobs.filter(
      (job) => job.status.toLowerCase() === statusFilter.toLowerCase(),
    );
  }, [jobs, statusFilter]);
 
  const paginatedJobs = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
 
    const end = start + itemsPerPage;
 
    return filteredJobs.slice(start, end);
  }, [filteredJobs, currentPage]);
 
  const formatDate = (date: Date | null) => {
    if (!date) return "—";
    return new Intl.DateTimeFormat("en-US", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    })
      .format(date)
      .replace(/\//g, "-");
  };
 
  const getStatusBadge = (status: Job["status"]) => {
    const styles = {
      completed: "bg-emerald-100 text-emerald-700",
      pending: "bg-amber-100 text-amber-700",
      running: "bg-amber-100 text-amber-700",
      failed: "bg-red-100 text-red-700",
    };
 
    const labels = {
      completed: "Completed",
      pending: "Running",
      running: "Running",
      failed: "Failed",
    };
 
    return (
      <span
        className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${styles[status]}`}
      >
        {labels[status]}
      </span>
    );
  };
 
  const handleRun = async (job: Job) => {
    // Check if job has basic configuration
    console.log("Job config:", {
      category: job.category,
      features: job.features,
      target: job.target,
      datasetName: job.datasetName,
    });
 
    if (!job.category && !job.feature) {
      alert("Job is missing task type (category). Please edit the job first.");
      return;
    }
 
    if (!job.target) {
      alert("Job is missing target column. Please edit the job first.");
      return;
    }
 
    if (!job.datasetName) {
      alert("Job is missing dataset. Please edit the job first.");
      return;
    }
 
    setRunningJobId(job.id);
    setRunningMessage("Preparing dataset...");
 
    try {
      const userDataString = localStorage.getItem("aivolve_user");
      if (!userDataString) {
        throw new Error("User not found");
      }
 
      const userData = JSON.parse(userDataString);
      const userEmail = userData.email;
      const agentName = userData.agent_name || userData.name || "default";
      const userId = userData.user_id || userData.id || "";
 
      // ✅ If features are not loaded, fetch them now
      let features = job.features || [];
 
      if (features.length === 0) {
        setRunningMessage("Loading dataset features...");
 
        const blobPath = `${userId}/${agentName}/${job.datasetName}`;
        const previewUrl = `https://api.veriton.ai/api/service3/data_preview?blob_path=${encodeURIComponent(blobPath)}&user_email=${encodeURIComponent(userEmail)}`;
 
        const previewResponse = await fetch(previewUrl, {
          method: "GET",
          headers: { accept: "application/json" },
        });
 
        if (!previewResponse.ok) {
          throw new Error(
            `Failed to fetch dataset features: ${previewResponse.status}`,
          );
        }
 
        const previewData = await previewResponse.json();
 
        if (!previewData.preview?.columns) {
          throw new Error("Invalid dataset preview");
        }
 
        // Get all columns except target
        features = previewData.preview.columns.filter(
          (col: string) => col !== job.target,
        );
 
        if (features.length === 0) {
          throw new Error("No features available for training.");
        }
 
        console.log("Fetched features:", features);
      }
 
      // Step 1: Download file from blob storage
      setRunningMessage("Downloading dataset...");
      const blobPath = `${userId}/${agentName}/${job.datasetName}`;
      const downloadUrl = `https://api.veriton.ai/api/service3/download_predictions?blob_path=${encodeURIComponent(blobPath)}&user_email=${encodeURIComponent(userEmail)}`;
 
      const downloadResponse = await fetch(downloadUrl, {
        method: "GET",
        headers: { accept: "application/json" },
      });
 
      if (!downloadResponse.ok) {
        throw new Error(`Failed to download file: ${downloadResponse.status}`);
      }
 
      const csvText = await downloadResponse.text();
      const fileBlob = new Blob([csvText], { type: "text/csv" });
 
      // Step 2: Prepare FormData for training
      setRunningMessage("Training model... This may take a few minutes.");
      const formData = new FormData();
      formData.append("file", fileBlob, job.datasetName);
      formData.append(
        "task",
        featureToTaskMap[job.category] || job.category.toLowerCase(),
      );
      formData.append("target", job.target);
      formData.append("user_email", userEmail);
 
      const apiModelName = job.model
        ? modelNameToAPI[job.model] ||
          job.model.toLowerCase().replace(/\s+/g, "_")
        : "";
      formData.append("models", apiModelName);
      formData.append("metric", "");
      formData.append("preprocessing_mode", "simple");
      formData.append("use_cleaning", "true");
      formData.append("use_feature_selection", "true");
      formData.append("use_optuna", "true");
      formData.append("optuna_trials", "2");
      formData.append("time_budget", "180");
      formData.append("test_size", "0.2");
      formData.append("test_file", "");
 
      // Step 3: Call build_ml_model API
      const buildResponse = await fetch(
        "https://api.veriton.ai/api/service3/build_ml_model",
        {
          method: "POST",
          body: formData,
        },
      );
 
      if (!buildResponse.ok) {
        const errorData = await buildResponse.json().catch(() => ({}));
        throw new Error(
          errorData.detail || `API failed: ${buildResponse.status}`,
        );
      }
 
      const result = await buildResponse.json();
      console.log("Model trained successfully:", result);
 
      // Convert API model name back to UI format
      const uiModelName =
        apiModelToUI[result.best_model?.toLowerCase()] || result.best_model;
 
      // Update job with new results
      updateJob(job.id, {
        id: result.model_id,
        feature: job.category,
        model: uiModelName,
        features: features, // ✅ Save the features we used
        category: job.category,
        target: job.target,
        status: "completed",
        task_type: result.task_type,
        testAccuracy: result.primary_score?.toString(),
        lastRun: new Date(),
      });
 
      setRunningMessage("Training complete! Opening results...");
 
      // Wait a bit for the update to propagate
      await new Promise((resolve) => setTimeout(resolve, 500));
 
      // Step 4: Open JobViewModal with updated job
      const updatedJob = {
        ...job,
        id: result.model_id,
        features: features,
        status: "completed" as const,
        lastRun: new Date(),
      };
 
      setSelectedJob(updatedJob);
      setIsViewModalOpen(true);
    } catch (err) {
      const errorMessage =
        err instanceof Error ? err.message : "Failed to train model";
      alert(`Error: ${errorMessage}`);
      console.error("Error training model:", err);
    } finally {
      setRunningJobId(null);
      setRunningMessage("");
    }
  };
 
  // Add these two functions (e.g. after handleRun or before return)
  const handleSelectDataset = async (
    ds: GlobalDataset | JobSpecificDataset,
  ) => {
    setSelectedDataset(ds);
    setPreviewData(null);
    setPreviewLoading(true);
 
    const userRaw = localStorage.getItem("user");
    const user = userRaw ? JSON.parse(userRaw) : null;
    const userId = user?.user_id || user?.id;
 
    if (!userId) {
      toast.error("User ID not found");
      setPreviewLoading(false);
      return;
    }
 
    // ─── This is the important change ───
    let jobId: string | undefined;
    let datasetName: string;
 
    if ("job_id" in ds && ds.job_id) {
      // Global dataset from /datasets API → use its own job_id
      jobId = ds.job_id;
      datasetName = ds.datasetName;
    } else if ("filename" in ds) {
      // Job-specific dataset from /list-datasets → fallback to current_job_id
      jobId = localStorage.getItem("current_job_id") || undefined;
      datasetName = ds.filename;
    }
 
    if (!jobId) {
      toast.error("Cannot preview: no job ID associated with this dataset");
      setPreviewLoading(false);
      return;
    }
 
    try {
      const url = `https://api.veriton.ai/api/service2/preview-dataset?user_id=${userId}&job_id=${jobId}&datasetname=${encodeURIComponent(datasetName)}`;
 
      const res = await fetch(url);
      if (!res.ok) {
        const errText = await res.text().catch(() => "");
        throw new Error(`Preview failed (${res.status}): ${errText}`);
      }
 
      const data = await res.json();
      setPreviewData(data);
      const filePath = `Files/Datasets/${data.user_id}/${data.job_id}/${data.dataset}.csv`
      setSelectedFilePath(filePath)
    } catch (err: any) {
      console.error("Preview error:", err);
      toast.error(err.message || "Failed to load dataset preview");
    } finally {
      setPreviewLoading(false);
    }
  };
 
  const startWorkflow = async (mode: "build" | "compare") => {
    if (!selectedDataset) return;
 
    const userRaw = localStorage.getItem("user");
    const user = userRaw ? JSON.parse(userRaw) : null;
    const userId = user?.user_id || user?.id;
 
    let jobId: string | undefined;
    let filename: string;
 
    if ("job_id" in selectedDataset && selectedDataset.job_id) {
      jobId = selectedDataset.job_id;
      filename = selectedDataset.datasetName;
    } else if ("filename" in selectedDataset) {
      jobId = localStorage.getItem("current_job_id") || undefined;
      filename = selectedDataset.filename;
    }
 
    if (!userId || !jobId || !filename) {
      toast.error("Cannot start: missing job ID or filename");
      return;
    }
 
    try {
      navigate(
  mode === "compare"
    ? "/workflow/automl/compare"
    : "/workflow/automl/build-model",
  {
    state: {
      filePath: selectedFilePath,
      datasetName: filename,
      mode: mode === "compare" ? "compare" : undefined,
    },
  },
)
    } catch (err: any) {
      toast.error(`Preparation failed for "${filename}": ${err.message}`);
    }
  };
 
  const handleView = (job: Job) => {
    setSelectedJob(job);
    setIsViewModalOpen(true);
  };
 
  const handleEdit = (job: Job) => {
    setSelectedJob(job);
    setIsEditModalOpen(true);
  };
 
  const handleCreateJob = () => {
    if (jobName.trim()) {
      navigate("/workflow/automl/select-dataset", {
        state: { jobName: jobName.trim(), initialTab: "data-source" },
      });
      setIsCreateModalOpen(false);
      setJobName("");
    }
  };
 
  const handleRefresh = async () => {
    await fetchJobs(currentPage);
  };
 
  //   if (!isAuthenticated) return null;
 
  return (
    <div className="min-h-screen h-screen bg-background flex flex-col overflow-hidden">
      <Header />
 
      <div className="flex-1 flex flex-col overflow-auto">
        <main className="px-6 py-6">
          <div className="max-w-7xl mx-auto w-full">
            {/* ================= AutoML Intro ================= */}
 
            <div className="mb-10 flex items-start justify-between">
              <div>
                <h1 className="text-3xl font-bold text-foreground">
                  AutoML Workspace
                </h1>
 
                <p className="text-muted-foreground mt-2 max-w-2xl">
                  Build, compare, and test machine learning models automatically
                  using your datasets. Manage all trained models below.
                </p>
              </div>
 
              <div className="flex items-center gap-3">
                <Button
                  variant="outline"
                  onClick={() =>
                    navigate("/workflow/automl/test", {
                      state: { initialTab: "test" },
                    })
                  } // ← your test flow path
                >
                  Test Model
                </Button>
              </div>
            </div>
            {/* ─── NEW: Dataset Selection Section ─── */}
            {/* ================= DATASET SECTION ================= */}
 
            <div className="bg-card border border-border rounded-xl shadow-sm mb-10 overflow-hidden">
              {/* Header */}
              <div className="px-6 py-4 border-b">
                <h2 className="text-lg font-semibold">Select Dataset</h2>
              </div>
 
              <div className="flex h-[480px]">
                {/* ================= Sidebar – all datasets in one list ================= */}
                <div className="w-[300px] border-r bg-muted/20 overflow-y-auto">
                  {dsLoading ? (
                    <div className="p-6 text-sm text-muted-foreground">
                      Loading datasets...
                    </div>
                  ) : globalDatasets.length === 0 &&
                    jobDatasets.length === 0 ? (
                    <div className="p-6 text-sm text-muted-foreground">
                      No datasets available
                    </div>
                  ) : (
                    // ─── Flat combined list: global + job-specific ───
                    [...jobDatasets, ...globalDatasets].map((ds) => {
                      const isGlobal = "datasetName" in ds;
                      const name = isGlobal ? ds.datasetName : ds.filename;
 
                      const rows = isGlobal ? ds.rows : null;
                      const columns = isGlobal ? ds.columns : null;
                      const dateInfo = isGlobal ? ds.lastRun : ds.date_modified;
 
                      const isSelected =
                        selectedDataset &&
                        ((isGlobal &&
                          "datasetName" in selectedDataset &&
                          selectedDataset.datasetName === name) ||
                          (!isGlobal &&
                            "filename" in selectedDataset &&
                            selectedDataset.filename === name));
 
                      return (
                        <button
                          key={`${isGlobal ? "g" : "j"}-${name}`}
                          onClick={() => handleSelectDataset(ds)}
                          className={cn(
                            "w-full text-left px-5 py-4 border-l-2 transition-all duration-200",
                            isSelected
                              ? "border-primary bg-background"
                              : "border-transparent hover:bg-background",
                          )}
                        >
                          <div className="font-medium text-sm truncate">
                            {name}
                          </div>
 
                          <div className="text-xs text-muted-foreground mt-1 flex flex-wrap gap-x-2">
                            {rows != null && (
                              <>
                                {rows} rows<span className="mx-1">•</span>
                              </>
                            )}
                            {columns != null && (
                              <>
                                {columns} columns<span className="mx-1">•</span>
                              </>
                            )}
                            {dateInfo && (
                              <span>
                                {isGlobal ? "Last run: " : "Modified: "}
                                {dateInfo}
                              </span>
                            )}
                          </div>
                        </button>
                      );
                    })
                  )}
                </div>
 
                {/* ================= Preview Panel ================= */}
 
                <div className="flex-1 flex flex-col bg-background">
                  {selectedDataset ? (
                    <>
                      {/* Preview Header */}
 
                      <div className="px-6 py-4 border-b flex items-center justify-between">
                        <div>
                          <h3 className="font-semibold">
                            {"datasetName" in selectedDataset &&
                              selectedDataset.datasetName}
                          </h3>
 
                          <p className="text-xs text-muted-foreground">
                            Dataset Preview
                          </p>
                        </div>
 
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            onClick={() => startWorkflow("build")}
                            disabled={!previewData}
                          >
                            Build Model
                          </Button>
 
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => startWorkflow("compare")}
                            disabled={!previewData}
                          >
                            Compare
                          </Button>
                        </div>
                      </div>
 
                      {/* Preview Table */}
 
                      <div className="flex-1 overflow-auto">
                        {previewLoading ? (
                          <div className="flex items-center justify-center h-full text-sm text-muted-foreground">
                            Loading preview...
                          </div>
                        ) : previewData ? (
                          <table className="w-full text-sm">
                            <thead className="bg-muted sticky top-0">
                              <tr>
                                {previewData.columns.map((col) => (
                                  <th
                                    key={col}
                                    className="px-4 py-3 text-left border-b"
                                  >
                                    {col}
                                  </th>
                                ))}
                              </tr>
                            </thead>
 
                            <tbody>
                              {previewData.preview_rows.map((row, i) => (
                                <tr key={i} className="hover:bg-muted/30">
                                  {previewData.columns.map((col) => (
                                    <td
                                      key={col}
                                      className="px-4 py-2 border-b"
                                    >
                                      {row[col] ?? "—"}
                                    </td>
                                  ))}
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        ) : (
                          <div className="flex items-center justify-center h-full text-muted-foreground">
                            Preview not available
                          </div>
                        )}
                      </div>
                    </>
                  ) : (
                    <div className="flex items-center justify-center h-full text-muted-foreground">
                      Select a dataset to preview
                    </div>
                  )}
                </div>
              </div>
            </div>
 
            {/* Header */}
            <div className="flex items-start justify-between mb-8">
              <div>
                <h1 className="text-3xl font-bold text-foreground mb-1">
                  Trained Models
                </h1>
                {/* <p className="text-muted-foreground">All machine learning models created using AutoML.</p> */}
              </div>
              <div className="flex items-center gap-3"></div>
            </div>
 
            {/* Error Display */}
            {error && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center justify-between">
                <p className="text-red-700 text-sm">{error}</p>
                <Button variant="outline" size="sm" onClick={handleRefresh}>
                  Try Again
                </Button>
              </div>
            )}
 
            {/* Running Job Status */}
            {runningJobId && (
              <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg flex items-center gap-3">
                <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
                <div>
                  <p className="text-blue-800 font-medium text-sm">
                    Training in progress...
                  </p>
                  <p className="text-blue-600 text-xs mt-0.5">
                    {runningMessage}
                  </p>
                </div>
              </div>
            )}
 
            {/* Filters Row */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-1 bg-muted/50 rounded-full p-1">
                {["all", "completed", "running", "failed"].map((status) => (
                  <button
                    key={status}
                    onClick={() => setStatusFilter(status)}
                    className={`px-4 py-2 text-sm font-medium rounded-full transition-colors ${
                      statusFilter === status
                        ? "bg-primary text-primary-foreground"
                        : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {status === "all"
                      ? "All"
                      : status.charAt(0).toUpperCase() + status.slice(1)}
                  </button>
                ))}
              </div>
            </div>
 
            {/* Jobs Table */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-card rounded-xl border border-border overflow-hidden"
            >
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="px-6 py-4 text-left text-sm font-medium text-muted-foreground">
                        Job
                      </th>
                      <th className="px-6 py-4 text-left text-sm font-medium text-muted-foreground">
                        Category
                      </th>
                      <th className="px-6 py-4 text-left text-sm font-medium text-muted-foreground">
                        Model
                      </th>
                      <th className="px-6 py-4 text-left text-sm font-medium text-muted-foreground">
                        Created At
                      </th>
                      <th className="px-6 py-4 text-left text-sm font-medium text-muted-foreground">
                        Last Run
                      </th>
                      <th className="px-6 py-4 text-left text-sm font-medium text-muted-foreground">
                        Status
                      </th>
                      <th className="px-6 py-4 text-left text-sm font-medium text-primary">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {loading ? (
                      <tr>
                        <td colSpan={7} className="px-6 py-12 text-center">
                          <div className="flex items-center justify-center gap-2">
                            <RefreshCw className="w-5 h-5 animate-spin text-primary" />
                            <span className="text-muted-foreground">
                              Loading jobs...
                            </span>
                          </div>
                        </td>
                      </tr>
                    ) : filteredJobs.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="px-6 py-16 text-center">
                          <h3 className="text-lg font-semibold mb-2">
                            No models created yet
                          </h3>
                          <p className="text-sm text-muted-foreground mb-4">
                            Start by building your first AutoML model.
                          </p>
                          <Button
                            onClick={() =>
                              navigate("/workflow/automl/select-dataset")
                            }
                          >
                            Build Your First Model
                          </Button>
                        </td>
                      </tr>
                    ) : (
                      filteredJobs.map((job, index) => {
                        const jobNumber =
                          (currentPage - 1) * itemsPerPage + index + 1;
                        return (
                          <motion.tr
                            key={job.id}
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            transition={{ delay: index * 0.03 }}
                            className="border-b border-border/50 hover:bg-muted/20"
                          >
                            <td className="px-6 py-4 font-medium text-foreground">
                              Job_{jobNumber}
                            </td>
                            <td className="px-6 py-4 text-primary">
                              {job.category || "Unknown"}
                            </td>
                            <td className="px-6 py-4 text-muted-foreground">
                              {job.model}
                            </td>
                            <td className="px-6 py-4 text-muted-foreground">
                              {formatDate(job.createdAt)}
                            </td>
                            <td className="px-6 py-4 text-muted-foreground">
                              {formatDate(job.lastRun)}
                            </td>
                            <td className="px-6 py-4">
                              {getStatusBadge(job.status)}
                            </td>
                            <td className="px-6 py-4">
                              <div className="flex items-center gap-3">
                                <button
                                  onClick={() => handleRun(job)}
                                  disabled={runningJobId === job.id}
                                  className="text-muted-foreground hover:text-foreground transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                                  title="Run job"
                                >
                                  {runningJobId === job.id ? (
                                    <Loader2 className="w-5 h-5 animate-spin" />
                                  ) : (
                                    <Play className="w-5 h-5" />
                                  )}
                                </button>
                                <button
                                  onClick={() => handleView(job)}
                                  className="text-muted-foreground hover:text-foreground transition-colors"
                                  title="View details"
                                >
                                  <Eye className="w-5 h-5" />
                                </button>
                                <button
                                  onClick={() => handleEdit(job)}
                                  className="text-muted-foreground hover:text-foreground transition-colors"
                                  title="Edit job"
                                >
                                  <Edit className="w-5 h-5" />
                                </button>
                              </div>
                            </td>
                          </motion.tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </motion.div>
 
            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex items-center justify-center gap-2 mt-6">
                <button
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                  className="p-2 rounded-lg text-muted-foreground hover:text-foreground disabled:opacity-50"
                >
                  ‹
                </button>
                {Array.from({ length: Math.min(totalPages, 10) }, (_, i) => {
                  const page = i + 1;
                  if (
                    totalPages <= 10 ||
                    page <= 3 ||
                    page > totalPages - 2 ||
                    Math.abs(page - currentPage) <= 1
                  ) {
                    return (
                      <button
                        key={page}
                        onClick={() => setCurrentPage(page)}
                        className={`w-10 h-10 rounded-full text-sm font-medium transition-colors ${
                          currentPage === page
                            ? "bg-primary text-primary-foreground"
                            : "text-muted-foreground hover:text-foreground"
                        }`}
                      >
                        {page}
                      </button>
                    );
                  } else if (page === 4 && currentPage > 5) {
                    return (
                      <span key="dots1" className="text-muted-foreground">
                        ...
                      </span>
                    );
                  } else if (
                    page === totalPages - 2 &&
                    currentPage < totalPages - 4
                  ) {
                    return (
                      <span key="dots2" className="text-muted-foreground">
                        ...
                      </span>
                    );
                  }
                  return null;
                })}
                <button
                  onClick={() =>
                    setCurrentPage((p) => Math.min(totalPages, p + 1))
                  }
                  disabled={currentPage === totalPages}
                  className="p-2 rounded-lg text-muted-foreground hover:text-foreground disabled:opacity-50"
                >
                  ›
                </button>
              </div>
            )}
          </div>
        </main>
 
        {/* Create Job Modal */}
        <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Create New Job</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="job-name">Job Name</Label>
                <Input
                  id="job-name"
                  placeholder="Enter job name..."
                  value={jobName}
                  onChange={(e) => setJobName(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") handleCreateJob();
                  }}
                  autoFocus
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsCreateModalOpen(false)}
              >
                Cancel
              </Button>
              <Button onClick={handleCreateJob} disabled={!jobName.trim()}>
                Next: Select Datasource
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
 
        {/* Modals */}
        <JobViewModal
          isOpen={isViewModalOpen}
          onClose={() => setIsViewModalOpen(false)}
          job={selectedJob}
        />
 
        <JobEditModal
          isOpen={isEditModalOpen}
          onClose={() => setIsEditModalOpen(false)}
          job={selectedJob}
        />
 
        {/* Chatbot */}
        <Chatbot />
      </div>
    </div>
  );
};
 
export default AutoMLJobs;