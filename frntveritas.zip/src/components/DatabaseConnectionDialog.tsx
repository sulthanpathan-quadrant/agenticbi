import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Database, Loader2 } from "lucide-react";
import { useState } from "react";
import { listDatabaseTables } from "@/components/api/api"; 
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";

interface DatabaseConnectionDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConnect: (data: {
    server: string;
    database: string;
    username: string;
    password:string;
    selectedTables: string[];
  }) => void;
}

export function DatabaseConnectionDialog({
  open,
  onOpenChange,
  onConnect,
}: DatabaseConnectionDialogProps) {
  const { toast } = useToast();

  const [server, setServer] = useState("");
  const [database, setDatabase] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const [loading, setLoading] = useState(false);
  const [tables, setTables] = useState<string[]>([]);
  const [selectedTables, setSelectedTables] = useState<string[]>([]);
  const [connected, setConnected] = useState(false);


  const resetDialog = () => {
  setServer("");
  setDatabase("");
  setUsername("");
  setPassword("");
  setTables([]);
  setSelectedTables([]);
  setConnected(false);
  setLoading(false);
};


  const handleConnect = async () => {
    try {
      setLoading(true);
      const res = await listDatabaseTables({
        server,
        database,
        username,
        password,
      });

      setTables(res.tables || []);
      setConnected(true);
toast({
  title: "Database connected successfully",
  duration: 1000, // disappears after 1 second
});

    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Connection failed",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  const toggleTable = (table: string) => {
    setSelectedTables((prev) =>
      prev.includes(table)
        ? prev.filter((t) => t !== table)
        : [...prev, table]
    );
  };

  const handleConfirm = () => {
    onConnect({
      server,
      database,
      username,
      password,
      selectedTables,
    });
    resetDialog();
    onOpenChange(false);
  };

  return (
    // <Dialog open={open} onOpenChange={onOpenChange}>
     <Dialog
  open={open}
  onOpenChange={(isOpen) => {
    if (!isOpen) resetDialog();
    onOpenChange(isOpen);
  }}
>

      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-2xl">Database Connection</DialogTitle>
          <DialogDescription>
            Connect and select tables
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
  {!connected && (
    <>
      {/* Credentials */}
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Server</Label>
          <Input
            value={server}
            onChange={(e) => setServer(e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <Label>Database</Label>
          <Input
            value={database}
            onChange={(e) => setDatabase(e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Username</Label>
          <Input
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <Label>Password</Label>
          <Input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
      </div>

      <div className="flex justify-end gap-3 pt-4">
        {/* <Button variant="outline" onClick={() => onOpenChange(false)}>
          Cancel
        </Button> */}
        <Button
  variant="outline"
  onClick={() => {
    resetDialog();
    onOpenChange(false);
  }}
>
  Cancel
</Button>


        <Button onClick={handleConnect} disabled={loading}>
          {loading ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <Database className="h-4 w-4 mr-2" />
          )}
          Connect
        </Button>
      </div>
    </>
     )}



          {connected && (
            <>
              {/* Table Selection */}
              <div className="space-y-3">
                <Label>Select Tables</Label>

                <div className="max-h-60 overflow-auto border rounded-md p-3 space-y-2">
                  {tables.map((table) => (
                    <div
                      key={table}
                      className="flex items-center gap-2"
                    >
                      <Checkbox
                        checked={selectedTables.includes(table)}
                        onCheckedChange={() => toggleTable(table)}
                      />
                      <span className="text-sm">{table}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Footer */}
              <div className="flex justify-end gap-3 pt-4">
                <Button
                  variant="outline"
                  onClick={() => setConnected(false)}
                >
                  Back
                </Button>

                <Button
                  onClick={handleConfirm}
                  disabled={selectedTables.length === 0}
                >
                 Add Files ({selectedTables.length})
                </Button>
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
