// 

import { useState, useEffect, useRef, useCallback } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  X,
  Search,
  Plus,
  Grid3X3,
  Settings,
  Edit,
} from "lucide-react";
import { toast } from "sonner";
 
interface Job {
  id: string;
  name: string;
  category: string;
  stages: number;
  steps: {
    dqRules: "skipped" | "executed";
    ner: "skipped" | "executed";
    businessLogic: "skipped" | "executed";
    dataTransformations: "skipped" | "executed";
  };
}
 
interface CanvasJob extends Job {
  x: number;
  y: number;
}
 
interface Connection {
  from: string;
  to: string;
}
 
const API_BASE = "https://20.81.213.147";
 
const CreatePipeline = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const isEditing = !!id;
  const canvasRef = useRef<HTMLDivElement>(null);
 
  const [pipelineName, setPipelineName] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [availableJobs, setAvailableJobs] = useState<Job[]>([]);
  const [canvasJobs, setCanvasJobs] = useState<CanvasJob[]>([]);
  const [connections, setConnections] = useState<Connection[]>([]);
  const [snapToGrid, setSnapToGrid] = useState(true);
  const [connectingFrom, setConnectingFrom] = useState<string | null>(null);
  const [draggingJob, setDraggingJob] = useState<string | null>(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [loadingJobs, setLoadingJobs] = useState(true);
  const [loadingPipeline, setLoadingPipeline] = useState(isEditing);
 
  // Get user_id
  const user = localStorage.getItem("user") ? JSON.parse(localStorage.getItem("user") || "{}") : {};
  const userId = user?.id || user?.user_id || "661ff9b1-6f16-4276-a393-bb13aec8f9a4";
 
  // Fetch ALL available jobs (sidebar)
  useEffect(() => {
    const fetchAvailableJobs = async () => {
      setLoadingJobs(true);
      try {
        const response = await fetch(
          `https://4.227.238.34/get-all-jobs?user_id=${userId}`,
          {
            method: "GET",
            headers: { "Content-Type": "application/json" },
          }
        );
 
        if (!response.ok) throw new Error(`Failed to fetch jobs: ${response.status}`);
 
        const data = await response.json();
 
        const jobs: Job[] = (data.jobs || []).map((j: any) => ({
          id: j.job_id,
          name: j.job_name || "Unnamed Job",
          category: "Unknown",
          stages: 4,
          steps: {
            dqRules: "skipped",
            ner: "skipped",
            businessLogic: "skipped",
            dataTransformations: "skipped",
          },
        }));
 
        setAvailableJobs(jobs);
      } catch (err: any) {
        console.error("Failed to fetch available jobs:", err);
        toast.error("Could not load available jobs");
      } finally {
        setLoadingJobs(false);
      }
    };
 
    fetchAvailableJobs();
  }, [userId]);
 
  // When editing: fetch pipeline details + populate canvas
  useEffect(() => {
    if (!isEditing) {
      setLoadingPipeline(false);
      return;
    }
 
    const fetchPipelineDetails = async () => {
      setLoadingPipeline(true);
      try {
        const response = await fetch(
          `${API_BASE}/view-pipeline?user_id=${userId}&pipeline_id=${id}`,
          {
            method: "GET",
            headers: { "Content-Type": "application/json" },
          }
        );
 
        if (!response.ok) throw new Error(`Failed to fetch pipeline: ${response.status}`);
 
        const data = await response.json();
 
        setPipelineName(data.pipeline_name || "Unnamed Pipeline");
 
        const pipelineJobs: CanvasJob[] = (data.jobs || []).map((j: any, index: number) => ({
          id: j.job_id,
          name: j.job_name || "Unnamed Job",
          category: "Unknown",
          stages: 4,
          steps: {
            dqRules: "skipped",
            ner: "skipped",
            businessLogic: "skipped",
            dataTransformations: "skipped",
          },
          x: 60 + (index % 2) * 400,
          y: 60 + Math.floor(index / 2) * 300,
        }));
 
        setCanvasJobs(pipelineJobs);
      } catch (err: any) {
        console.error("Failed to load pipeline:", err);
        toast.error("Could not load pipeline details for editing");
      } finally {
        setLoadingPipeline(false);
      }
    };
 
    fetchPipelineDetails();
  }, [isEditing, id, userId]);
 
  const filteredJobs = availableJobs.filter((job) =>
    job.name.toLowerCase().includes(searchQuery.toLowerCase())
  );
 
  const snapPosition = (value: number) => {
    if (!snapToGrid) return value;
    const gridSize = 20;
    return Math.round(value / gridSize) * gridSize;
  };
 
  const addJobToCanvas = (job: Job) => {
    if (canvasJobs.find((j) => j.id === job.id)) {
      toast.error("Job already added to canvas");
      return;
    }
    const newCanvasJob: CanvasJob = {
      ...job,
      x: snapPosition(60 + (canvasJobs.length % 2) * 400),
      y: snapPosition(60 + Math.floor(canvasJobs.length / 2) * 300),
    };
    setCanvasJobs([...canvasJobs, newCanvasJob]);
  };
 
  const removeJobFromCanvas = (jobId: string) => {
    setCanvasJobs(canvasJobs.filter((j) => j.id !== jobId));
    setConnections(connections.filter((c) => c.from !== jobId && c.to !== jobId));
  };
 
  const clearCanvas = () => {
    setCanvasJobs([]);
    setConnections([]);
  };
 
  const handleMouseDown = (e: React.MouseEvent, jobId: string) => {
    const job = canvasJobs.find((j) => j.id === jobId);
    if (!job) return;
 
    setDraggingJob(jobId);
    setDragOffset({
      x: e.clientX - job.x,
      y: e.clientY - job.y,
    });
  };
 
  const handleMouseMove = useCallback(
    (e: MouseEvent) => {
      if (!draggingJob || !canvasRef.current) return;
 
      const canvasRect = canvasRef.current.getBoundingClientRect();
      const newX = snapPosition(
        e.clientX - canvasRect.left - dragOffset.x + canvasRef.current.scrollLeft
      );
      const newY = snapPosition(
        e.clientY - canvasRect.top - dragOffset.y + canvasRef.current.scrollTop
      );
 
      setCanvasJobs((prev) =>
        prev.map((j) =>
          j.id === draggingJob ? { ...j, x: Math.max(0, newX), y: Math.max(0, newY) } : j
        )
      );
    },
    [draggingJob, dragOffset, snapToGrid]
  );
 
  const handleMouseUp = useCallback(() => {
    setDraggingJob(null);
  }, []);
 
  useEffect(() => {
    if (draggingJob) {
      window.addEventListener("mousemove", handleMouseMove);
      window.addEventListener("mouseup", handleMouseUp);
      return () => {
        window.removeEventListener("mousemove", handleMouseMove);
        window.removeEventListener("mouseup", handleMouseUp);
      };
    }
  }, [draggingJob, handleMouseMove, handleMouseUp]);
 
  const handleConnectionStart = (jobId: string, side: "left" | "right") => {
    if (connectingFrom === null) {
      setConnectingFrom(jobId);
    } else if (connectingFrom !== jobId) {
      const existing = connections.find(
        (c) =>
          (c.from === connectingFrom && c.to === jobId) ||
          (c.from === jobId && c.to === connectingFrom)
      );
      if (!existing) {
        setConnections([...connections, { from: connectingFrom, to: jobId }]);
      }
      setConnectingFrom(null);
    } else {
      setConnectingFrom(null);
    }
  };
 
  const savePipeline = async () => {
    if (!pipelineName.trim()) {
      toast.error("Please enter a pipeline name");
      return;
    }
    if (canvasJobs.length === 0) {
      toast.error("Please add at least one job to the pipeline");
      return;
    }
 
    const payload = {
      user_id: userId,
      pipeline_name: pipelineName.trim(),
      job_ids: canvasJobs.map((j) => j.id),
      description: "", // can be made editable later if needed
    };
 
    const endpoint = isEditing
      ? `${API_BASE}/edit-pipeline`
      : `${API_BASE}/create-pipeline`;
 
    const method = "POST"; // both create and edit use POST according to your Swagger
 
    try {
      const response = await fetch(endpoint, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(
          isEditing
            ? { ...payload, pipeline_id: id }
            : payload
        ),
      });
 
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Save failed: ${response.status} - ${errorText}`);
      }
 
      const result = await response.json();
 
      if (result.status === "success") {
        toast.success(
          result.message ||
            (isEditing ? "Pipeline updated successfully" : "Pipeline created successfully")
        );
        navigate("/pipelines");
      } else {
        throw new Error(result.message || "Operation failed");
      }
    } catch (err: any) {
      console.error("Pipeline save error:", err);
      toast.error(err.message || "Could not save pipeline. Please try again.");
    }
  };
 
  const getStepStatus = (status: "skipped" | "executed") => {
    return status === "executed" ? (
      <Badge variant="outline" className="text-xs bg-blue-500/10 text-blue-500 border-blue-500/30">
        executed
      </Badge>
    ) : (
      <Badge variant="outline" className="text-xs">skipped</Badge>
    );
  };
 
  return (
    <div className="fixed inset-0 bg-background z-50 flex flex-col">
      {/* Header */}
      <div className="border-b border-border p-4 flex items-center justify-between bg-background">
        <div className="flex items-center gap-4">
          <h2 className="font-bold text-lg">{isEditing ? "Edit Pipeline" : "New Pipeline"}</h2>
          <Input
            value={pipelineName}
            onChange={(e) => setPipelineName(e.target.value)}
            placeholder="Enter pipeline name"
            className="w-56 bg-muted/30 border-border"
            disabled={loadingPipeline}
          />
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 px-3 py-1.5 bg-muted/30 rounded-lg">
            <Grid3X3 className="w-4 h-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">Snap to Grid</span>
            <Switch checked={snapToGrid} onCheckedChange={setSnapToGrid} />
          </div>
          <Button variant="ghost" onClick={clearCanvas} disabled={loadingPipeline}>
            Clear Canvas
          </Button>
          <Button variant="ghost" size="icon" onClick={() => navigate("/pipelines")}>
            <X className="w-5 h-5" />
          </Button>
        </div>
      </div>
 
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar - Available Jobs */}
        <div className="w-72 border-r border-border p-4 overflow-y-auto bg-background">
          <h3 className="font-semibold mb-4">
            Available Jobs {loadingJobs ? "(loading...)" : `(${filteredJobs.length})`}
          </h3>
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search jobs..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
              disabled={loadingJobs || loadingPipeline}
            />
          </div>
          <div className="space-y-2">
            {loadingJobs || loadingPipeline ? (
              <div className="text-center py-10 text-muted-foreground">
                {loadingPipeline ? "Loading pipeline..." : "Loading jobs..."}
              </div>
            ) : filteredJobs.length === 0 ? (
              <div className="text-center py-10 text-muted-foreground">No jobs found</div>
            ) : (
              filteredJobs.map((job) => (
                <Card
                  key={job.id}
                  className="p-3 cursor-pointer hover:bg-muted/50 transition-colors border-l-4 border-l-primary"
                  onClick={() => addJobToCanvas(job)}
                >
                  <p className="font-medium text-sm">{job.name}</p>
                  <p className="text-xs text-muted-foreground">{job.category}</p>
                  <Badge variant="secondary" className="mt-1 text-xs">
                    {job.stages} stages
                  </Badge>
                </Card>
              ))
            )}
          </div>
        </div>
 
        {/* Canvas Area */}
        <div className="flex-1 relative overflow-hidden bg-[#f8f9fb] dark:bg-[#1a1d21]">
          <div className="absolute top-4 left-4 text-sm font-medium text-foreground z-10">
            Pipeline Canvas
          </div>
          <div className="absolute top-4 right-4 text-sm text-muted-foreground flex items-center gap-1 z-10">
            <Plus className="w-4 h-4" /> Click jobs from sidebar to add, click blue dots to connect
          </div>
 
          <div
            ref={canvasRef}
            className="absolute inset-0 overflow-auto"
            style={{
              backgroundImage: `
                linear-gradient(to right, hsl(220 13% 91% / 0.8) 1px, transparent 1px),
                linear-gradient(to bottom, hsl(220 13% 91% / 0.8) 1px, transparent 1px)
              `,
              backgroundSize: "20px 20px",
            }}
          >
            <svg className="absolute inset-0 pointer-events-none" style={{ minWidth: "2000px", minHeight: "1200px" }}>
              <defs>
                <marker
                  id="arrowhead"
                  markerWidth="10"
                  markerHeight="7"
                  refX="9"
                  refY="3.5"
                  orient="auto"
                >
                  <polygon points="0 0, 10 3.5, 0 7" fill="hsl(220, 13%, 69%)" />
                </marker>
              </defs>
              {connections.map((conn, index) => {
                const fromJob = canvasJobs.find((j) => j.id === conn.from);
                const toJob = canvasJobs.find((j) => j.id === conn.to);
                if (!fromJob || !toJob) return null;
 
                const cardWidth = 260;
                const cardHeight = 200;
 
                const startX = fromJob.x + cardWidth;
                const startY = fromJob.y + cardHeight / 2;
                const endX = toJob.x;
                const endY = toJob.y + cardHeight / 2;
 
                const midX = startX + (endX - startX) / 2;
 
                return (
                  <path
                    key={`connection-${index}`}
                    d={`M ${startX} ${startY} L ${midX} ${startY} L ${midX} ${endY} L ${endX} ${endY}`}
                    stroke="hsl(220, 13%, 69%)"
                    strokeWidth="2"
                    fill="none"
                    markerEnd="url(#arrowhead)"
                  />
                );
              })}
            </svg>
 
            <div className="relative p-8" style={{ minHeight: "1200px", minWidth: "2000px" }}>
              {canvasJobs.map((job) => (
                <Card
                  key={job.id}
                  className={`job-card absolute w-[260px] bg-background shadow-md cursor-move select-none ${
                    connectingFrom === job.id ? "border-2 border-blue-400 ring-2 ring-blue-200/50" : "border border-blue-300/50"
                  }`}
                  style={{ left: job.x, top: job.y }}
                  onMouseDown={(e) => handleMouseDown(e, job.id)}
                >
                  <div
                    className="absolute left-0 top-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-blue-500 border-2 border-white cursor-pointer hover:scale-125 transition-transform z-50 shadow-md"
                    onMouseDown={(e) => { e.stopPropagation(); e.preventDefault(); }}
                    onClick={(e) => { e.stopPropagation(); e.preventDefault(); handleConnectionStart(job.id, "left"); }}
                  />
                  <div
                    className="absolute right-0 top-1/2 translate-x-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-blue-500 border-2 border-white cursor-pointer hover:scale-125 transition-transform z-50 shadow-md"
                    onMouseDown={(e) => { e.stopPropagation(); e.preventDefault(); }}
                    onClick={(e) => { e.stopPropagation(); e.preventDefault(); handleConnectionStart(job.id, "right"); }}
                  />
 
                  <div className="p-3 border-b border-border flex items-center justify-between">
                    <div>
                      <span className="font-semibold text-sm">{job.name}</span>
                      <p className="text-xs text-muted-foreground">{job.category}</p>
                    </div>
                    <div className="flex items-center gap-1">
                      <Button size="icon" variant="ghost" className="h-7 w-7" onClick={(e) => { e.stopPropagation(); }}>
                        <Settings className="w-4 h-4" />
                      </Button>
                      <Button size="icon" variant="ghost" className="h-7 w-7" onClick={(e) => { e.stopPropagation(); }}>
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-7 w-7"
                        onClick={(e) => { e.stopPropagation(); removeJobFromCanvas(job.id); }}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  <div className="p-3">
                    <Badge variant="secondary" className="text-xs mb-3">
                      {job.stages} stages
                    </Badge>
                    <div className="text-xs font-medium text-muted-foreground mb-2">STAGES</div>
                    <div className="space-y-1.5">
                      <div className="flex justify-between items-center">
                        <span className="flex items-center gap-2 text-xs">
                          <Settings className="w-3 h-3 text-muted-foreground" /> rules
                        </span>
                        {getStepStatus(job.steps.dqRules)}
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="flex items-center gap-2 text-xs">
                          <Settings className="w-3 h-3 text-muted-foreground" /> ner
                        </span>
                        {getStepStatus(job.steps.ner)}
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="flex items-center gap-2 text-xs">
                          <Settings className="w-3 h-3 text-muted-foreground" /> businessLogic
                        </span>
                        {getStepStatus(job.steps.businessLogic)}
                      </div>
                    </div>
                    <div className="flex justify-between text-xs text-muted-foreground mt-3 pt-2 border-t border-border">
                      <span>In: <span className="text-foreground">data</span></span>
                      <span>Out: <span className="text-foreground">data</span></span>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
 
      {/* Footer */}
      <div className="border-t border-border p-4 flex justify-end gap-3 bg-background">
        <Button variant="outline" onClick={() => navigate("/pipelines")} disabled={loadingPipeline}>
          Cancel
        </Button>
        <Button onClick={savePipeline} disabled={loadingPipeline || loadingJobs}>
          {isEditing ? "Update Pipeline" : "Save Pipeline"}
        </Button>
      </div>
    </div>
  );
};
 
export default CreatePipeline;
 